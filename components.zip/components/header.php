<style>
.website-name {
    text-align: center;
    font-size: 20px;
    font-weight: bold;
    color: #000;
    margin-top: 10px;
    padding: 15px;
    letter-spacing: 2px;
    text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.2);
    margin-right: auto; /* Move the element to the right */
}


</style>



<header class="header">
    <div class="flex">
        <a href="../all_posts.php" class="logo"><img src="https://cdn.pixabay.com/animation/2023/06/01/08/53/08-53-15-862_512.gif" width="100" height="100" alt=""></a>
        <h1 class="website-name"  >Neighborhood-Nest</h1>
        <nav class="navbar">
            <a href="all_posts.php" class="fas fa-home"></a>
            <a href="add_products.php" class="fas fa-plus-circle"></a>
            <a href="search.php" class="fa fa-list"></a>
            
            <!-- <a href="login.php" class="fas fa-sign-in-alt"></a> -->
            <!-- <a href="register.php" class="fas fa-user-plus"></a> -->
            <div id="user-btn" class="fas fa-user-circle"></div>
        </nav>

        

        

        <div class="profile">
            <!-- PHP code starts here -->
            <?php
            $select_profile = $conn->prepare("select * From `users` WHERE id = ? LIMIT 1");
            $select_profile->execute([$user_id]);
            if ($select_profile->rowCount() > 0) {
                $fetch_profile = $select_profile->fetch(PDO::FETCH_ASSOC);
            ?>

            <?php if ($fetch_profile['image'] != '') { ?>
                <img src="uploaded_file/<?= $fetch_profile['image']; ?>" class="image" alt="">
            <?php } ?>

            <p><?= $fetch_profile['name']; ?></p>
            <div class="flex-btn">
                <a href="update.php" class="btn">Update profile</a>
                <a href="components/logout.php" class="delete-btn" onclick="return confirm('logout from this website');">logout</a>
            </div>

            <?php } else { ?>
                <img src="https://cdn.pixabay.com/animation/2022/12/05/10/47/10-47-58-930_512.gif" class="image" alt="">
                <p class="name">Please login or register first!</p>
                <div class="flex-btn">
                    <a href="login.php" class="btn">Login</a>
                    <a href="register.php" class="delete-btn">register</a>
                </div>
            <?php } ?>
            <!-- PHP code ends here -->
        </div>
    </div>
</header>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    
</head>
<body>
    
</body>
</html>

