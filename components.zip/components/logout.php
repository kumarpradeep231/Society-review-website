<?php
    include 'connection.php';

    setcookie('user_id', '', time() - 1, '/');

    // Adjust the path to match the location of all_posts.php
    header('location:../all_posts.php');
    exit();
?>
